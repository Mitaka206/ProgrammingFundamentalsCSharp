﻿using System.Collections.Generic;

namespace p11_StudentGroup
{
    class Group
    {
        public string Town { get; set; }
        public List<Student> Students { get; set; }
    }
}
