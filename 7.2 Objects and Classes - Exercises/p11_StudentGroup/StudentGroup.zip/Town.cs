﻿
using System.Collections.Generic;

namespace p11_StudentGroup
{
    class Town
    {
        public string Name { get; set; }
        public int SeatsCount { get; set; }
        public List<Student> Students { get; set; }
    }
}
